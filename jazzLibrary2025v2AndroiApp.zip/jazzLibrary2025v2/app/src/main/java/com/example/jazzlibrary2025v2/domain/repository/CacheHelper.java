package com.example.jazzlibrary2025v2.domain.repository;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.jazzlibrary2025v2.domain.model.BootStrap;
import com.example.jazzlibrary2025v2.domain.model.Quote;
import com.example.jazzlibrary2025v2.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CacheHelper {
    private static final String QUOTES_CACHE_FILE = "quotes_cache.json";
    private static final long CACHE_VALIDITY_MS = 24 * 60 * 60 * 1000; // 24 hours


        // Add this new method to check cache validity
        public static boolean isCacheValid(Context context) {
            File file = new File(context.getFilesDir(), QUOTES_CACHE_FILE);
            return file.exists() &&
                    (System.currentTimeMillis() - file.lastModified()) < CACHE_VALIDITY_MS;
        }

    public static void saveQuotes(Context context, List<Quote> quotes) {
        new Thread(() -> {
            File file = new File(context.getFilesDir(), QUOTES_CACHE_FILE);
            Gson gson = new Gson();
            try (FileWriter writer = new FileWriter(file)) {
                gson.toJson(quotes, writer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static List<Quote> loadQuotes(Context context) {
        File file = new File(context.getFilesDir(), QUOTES_CACHE_FILE);
        if (!file.exists()) return null;

        // Check cache validity
        if (System.currentTimeMillis() - file.lastModified() > CACHE_VALIDITY_MS) {
            file.delete();
            return null;
        }

        try (FileReader reader = new FileReader(file)) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<Quote>>(){}.getType();
            return gson.fromJson(reader, type);
        } catch (IOException | JsonSyntaxException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Bootstrap cache methods
    public static void saveBootstrap(Context context, BootStrap bootstrap) {
        SharedPreferences prefs = context.getSharedPreferences(
                Constants.PREFS_NAME,
                Context.MODE_PRIVATE
        );

        Gson gson = new Gson();
        prefs.edit()
                .putString(Constants.KEY_BOOTSTRAP, gson.toJson(bootstrap))
                .putLong(Constants.KEY_BOOTSTRAP_TIME, System.currentTimeMillis())
                .apply();
    }

    public static BootStrap loadBootstrap(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(
                Constants.PREFS_NAME,
                Context.MODE_PRIVATE
        );
        String json = prefs.getString(Constants.KEY_BOOTSTRAP, null);
        return json != null ? new Gson().fromJson(json, BootStrap.class) : null;
    }

    public static boolean isBootstrapCacheValid(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(
                Constants.PREFS_NAME,
                Context.MODE_PRIVATE
        );
        long lastCacheTime = prefs.getLong(Constants.KEY_BOOTSTRAP_TIME, 0);
        return (System.currentTimeMillis() - lastCacheTime) < TimeUnit.HOURS.toMillis(24);
    }


}