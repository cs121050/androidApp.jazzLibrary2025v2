package com.example.jazzlibrary2025v2.domain.model;

import java.util.ArrayList;
import java.util.List;

public class GlobalData {
    private static List<Artist> artistList = new ArrayList<>();
    private static List<Video> videoList = new ArrayList<>();


    // Setter
    public static void setArtistList(List<Artist> artists) {
        artistList = artists;
    }

    // Getter
    public static List<Artist> getArtistList() {
        return artistList;
    }

    public static void setVideoList(List<Video> videos) {
        videoList = videos;
    }

    // Getter
    public static List<Video> getVideoList() {
        return videoList;
    }
}