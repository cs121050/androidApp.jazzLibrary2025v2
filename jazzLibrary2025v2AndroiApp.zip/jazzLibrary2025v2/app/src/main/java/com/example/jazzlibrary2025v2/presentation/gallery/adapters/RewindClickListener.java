package com.example.jazzlibrary2025v2.presentation.gallery.adapters;

import android.view.View;

public class RewindClickListener implements View.OnClickListener
{
    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            //handle multiple view click events
        }
    }
}