package com.example.jazzlibrary2025v2.utils;

public class Utils {

//    private static Drawable drawable_bass_icon ;
//    private static Drawable drawable_guitar_icon;
//    private static Drawable drawable_piano_icon;
//    private static Drawable drawable_drums_icon;
//    private static Drawable drawable_voice_icon ;
//    private static Drawable drawable_sax_icon ;
//    private static Drawable drawable_trumpet_icon ;
//    private static Drawable drawable_violin_icon ;
//    private static Drawable drawable_vibes_icon ;
//    private static Drawable drawable_clarinete_icon ;
//    private static Drawable drawable_trombone_icon ;
//    private static Drawable drawable_journalism_icon ;
//    private static Drawable drawable_other_icon;
//
//    List<Artist> artistList;
//    public List<Artist> getArtistList() {
//        return artistList;
//    }
//
//    public void getConstantGlobalResources(){
//        //TODO// make on <lIST> RETURNING function for each list ,,
//
//        //List<Type> typeList = GlobalData.getVideoList();
//        //List<Instrument> videoList = GlobalData.getVideoList();
//        //List<Duration> videoList = GlobalData.getVideoList();
//    }
//    public void getGlobalResources(){
//        //TODO// make on <lIST> RETURNING function for each list ,,
//        artistList = GlobalData.getArtistList();
//        //List<Video> videoList = GlobalData.getVideoList();
//    }
//
//    public void notAvailableOptionMessagee(){
//        Toast.makeText(getco, "this option is not available yet", Toast.LENGTH_SHORT).show();
//    }
//    public static void hideSoftKeyboard(Activity activity) {
//        //apla krivei to keyboard
//        InputMethodManager inputMethodManager =
//                (InputMethodManager) activity.getSystemService(
//                        Activity.INPUT_METHOD_SERVICE);
//        if(inputMethodManager.isAcceptingText()){
//            inputMethodManager.hideSoftInputFromWindow(
//                    activity.getCurrentFocus().getWindowToken(),
//                    0
//            );
//        }
//    }
//    public String durationNicknameGiver(String durationDatabasetechnicalName){
//
//        String durationNickname="";
//
//        if(durationDatabasetechnicalName.equals("5"))
//            durationNickname = "very short";
//        else if(durationDatabasetechnicalName.equals("5to15"))
//            durationNickname="short";
//        else if(durationDatabasetechnicalName.equals("15to30"))
//            durationNickname="medium";
//        else if(durationDatabasetechnicalName.equals("30to60"))
//            durationNickname="long";
//        else if(durationDatabasetechnicalName.equals("moreThan60"))
//            durationNickname="very long";
//
//        return durationNickname;
//    }
//    public static Chip setArtistChipSelectIcon(Chip chipArtist, int instrumentCipId){
//        if (instrumentCipId == 1) { //bass
//            chipArtist.setCheckedIcon(drawable_bass_icon);
//        } else if (instrumentCipId == 2) { //guitar
//            chipArtist.setCheckedIcon(drawable_guitar_icon);
//        } else if (instrumentCipId == 3) { //piano
//            chipArtist.setCheckedIcon(drawable_piano_icon);
//        } else if (instrumentCipId == 4) { //drums
//            chipArtist.setCheckedIcon(drawable_drums_icon);
//        } else if (instrumentCipId == 5) { //voice
//            chipArtist.setCheckedIcon(drawable_voice_icon);
//        } else if (instrumentCipId == 6) { //sax
//            chipArtist.setCheckedIcon(drawable_sax_icon);
//        } else if (instrumentCipId == 7) { //trumpet
//            chipArtist.setCheckedIcon(drawable_trumpet_icon);
//        } else if (instrumentCipId == 8) { //violin
//            chipArtist.setCheckedIcon(drawable_violin_icon);
//        } else if (instrumentCipId == 9) { //vibes
//            chipArtist.setCheckedIcon(drawable_vibes_icon);
//        } else if (instrumentCipId == 10) { //clarinete
//            chipArtist.setCheckedIcon(drawable_clarinete_icon);
//        } else if (instrumentCipId == 11) { //trombone
//            chipArtist.setCheckedIcon(drawable_trombone_icon);
//        } else if (instrumentCipId == 12) { //journalism
//            chipArtist.setCheckedIcon(drawable_journalism_icon);
//        } else if (instrumentCipId ==  13) { //other
//            chipArtist.setCheckedIcon(drawable_other_icon);
//        }
//        return chipArtist;
//
//
//    }



}
