package com.example.jazzlibrary2025v2.utils;

public class GlobalConfig {

    public static String publicServersIP ="192.168.1.77";
    public static String APIName ="";

    public static boolean gradientBackGround = false;
    public static boolean offlineMode = true;


}
