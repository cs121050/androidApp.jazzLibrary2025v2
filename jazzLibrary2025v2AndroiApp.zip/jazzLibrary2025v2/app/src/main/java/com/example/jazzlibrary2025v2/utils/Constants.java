package com.example.jazzlibrary2025v2.utils;

public class Constants {
    public static final String PREFS_NAME = "MyAppPreferences";
    public static final String KEY_BOOTSTRAP = "bootstrap_data";
    public static final String KEY_BOOTSTRAP_TIME = "bootstrap_cache_time";
    public static final String KEY_QUOTES = "quotes_data";
    public static final String KEY_QUOTES_TIME = "quotes_cache_time";
}